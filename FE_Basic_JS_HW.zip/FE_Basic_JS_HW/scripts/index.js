const stringArray = [
  "Параграф 1",
  "Параграф 2",
  "Параграф 3",
  "Параграф 4",
  "Параграф 5",
];

const paragraphContainer = document.getElementById("paragraphContainer");

function createParagraphs() {
  for (let i = 0; i < stringArray.length; i++) {
    const paragraph = document.createElement("p");
    paragraph.textContent = stringArray[i];

    paragraph.addEventListener("click", function () {
      toggleText(paragraph);
    });

    paragraphContainer.appendChild(paragraph);
  }
}

function toggleText(paragraph) {
  if (paragraph.textContent.includes("*")) {
    paragraph.textContent =
      stringArray[stringArray.indexOf(paragraph.textContent.replace("*", ""))];
  } else {
    paragraph.textContent = paragraph.textContent.replace(/[^\s]/g, "*");
  }
}

createParagraphs();

const booksArray = [
  {
    id: 1,
    title: "Книга 1",
    author: "Автор 1",
    description: "Описание 1",
    image: "images/book1.jpg",
    price: "$10",
  },
];

const bookContainer = document.getElementById("bookContainer");
const loadMoreButton = document.getElementById("loadMoreButton");

let currentIndex = 0;

function createBookCards(startIndex, endIndex) {
  const fragment = document.createDocumentFragment();

  for (let i = startIndex; i < endIndex && booksArray[i]; i++) {
    const book = booksArray[i];

    const card = document.createElement("div");

    const h2 = document.createElement("h2");
    h2.textContent = book.title || "No Title";

    const h3 = document.createElement("h3");
    h3.textContent = book.author || "No Author";

    const p = document.createElement("p");
    p.textContent = book.description || "No Description";

    const img = document.createElement("img");
    img.src = book.image || "";
    img.alt = book.title || "No Title";

    const span = document.createElement("span");
    span.textContent = book.price || "No Price";

    card.appendChild(h2);
    card.appendChild(h3);
    card.appendChild(p);
    card.appendChild(img);
    card.appendChild(span);

    fragment.appendChild(card);
  }

  bookContainer.appendChild(fragment);
}

function loadMoreBooks() {
  const nextIndex = currentIndex + 5;
  if (nextIndex < booksArray.length) {
    createBookCards(currentIndex, nextIndex);
    currentIndex = nextIndex;
  } else {
    loadMoreButton.disabled = true;
  }
}

loadMoreButton.addEventListener("click", function () {
  loadMoreBooks();
});

createBookCards(0, 5);
